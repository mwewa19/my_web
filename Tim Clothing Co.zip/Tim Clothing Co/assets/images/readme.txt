This folder should contain placeholder product images for the Tim Clothing Co. site.
You can replace these with real images. Expected filenames used by the scaffold:
- product1.jpg
- product2.jpg
- product3.jpg
- product4.jpg
- product5.jpg
- product6.jpg
